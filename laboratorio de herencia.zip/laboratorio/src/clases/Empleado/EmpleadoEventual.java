package clases.Empleado;

import javax.swing.JOptionPane;

public class EmpleadoEventual extends Empleado {
    
    private double honorariosPorHora;
    private String fechaTerminoContrato;

    public double getHonorariosPorHora() {
        return honorariosPorHora;
    }

    public void setHonorariosPorHora(double honorariosPorHora) {
        this.honorariosPorHora = honorariosPorHora;
    }

    public String getFechaTerminoContrato() {
        return fechaTerminoContrato;
    }

    public void setFechaTerminoContrato(String fechaTerminoContrato) {
        this.fechaTerminoContrato = fechaTerminoContrato;
    }
    
    @Override
    public void registrarDatos() {
        super.registrarDatos(); 

        boolean validInput = false;
        while (!validInput) {
            try {
                honorariosPorHora = Double.parseDouble(JOptionPane.showInputDialog("Ingrese los honorarios por hora"));
                validInput = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Debe ingresar un número válido para los honorarios");
            }
        }
        
        fechaTerminoContrato = JOptionPane.showInputDialog("Ingrese la fecha de término del contrato (dd/mm/aa)");
    }

    @Override
    public void imprimirDatosPersona(String datos) {
        super.imprimirDatosPersona(datos);

        datos = "Honorarios por Hora: " + honorariosPorHora + "\n";
        datos += "Fecha Termino del Contrato: " + fechaTerminoContrato + "\n";

        System.out.println(datos);
    }
}