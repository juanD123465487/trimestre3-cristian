    
public class Principal {
        public static void main(String arg[]) { 
            Procesos miProcesos = new Procesos();
    }
}